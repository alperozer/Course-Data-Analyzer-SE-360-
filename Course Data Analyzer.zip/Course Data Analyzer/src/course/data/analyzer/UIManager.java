/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package course.data.analyzer;

import java.awt.Color;
import java.awt.Image;
import java.util.List;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.CategorySeries;
import org.knowm.xchart.CategorySeries.CategorySeriesRenderStyle;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.PieChartBuilder;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.style.Styler.ChartTheme;
import org.knowm.xchart.style.Styler.LegendPosition;

/**
 *
 * @author alperozer
 */
public class UIManager extends javax.swing.JFrame
{

    private enum FileChooseState
    {
        ExamResults,
        StudentAttendance,
    }
    private CourseManager courseManager;
    private ResourceManager resourceManager;
    private MenuBarItem currentSelectedMenu;
    private Color selectedMenuItemColor = new Color(36, 152, 249);
    private Color unselectedMenuItemColor = new Color(53, 55, 61);
    private Color unselectedInnerMenuItemColor = new Color(26, 24, 26);
    private ArrayList<MenuBarItem> menuBarItems;
    private ArrayList<CourseAction> courseActions;
    private int selectedCourse = -1;
    private int selectedSection = -1;
    private FileChooseState fileChooseState;

    /**
     * Creates new form MainFrame
     */
    public UIManager()
    {

        initComponents();

        // Instantiate managers.
        courseActions = new ArrayList<CourseAction>();
        resourceManager = new ResourceManager();
        courseManager = new CourseManager(this, resourceManager);

        SetIcons();
        InitializeMenuBarItems();
        AddComponentListeners();
        SetUIChoices();

        // Load courses.
        courseManager.PopulateCourses();

    }

    private void SetIcons()
    {
        // Set app ico 
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/appicon.png")));

        // Resize Image Icons in the Menu
        ImageIcon dashboardIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/dashboard.png")));
        ImageIcon coursesIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/courses.png")));
        ImageIcon studentsIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/students.png")));
        ImageIcon examsIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/exam.png")));
        ImageIcon attendanceIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/attendance.png")));
        ImageIcon reportsIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/reports.png")));
        ImageIcon syllabusIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/syllabus.png")));
        ImageIcon settingsIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/settings.png")));
        ImageIcon chart1Icon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/chart1.png")));
        ImageIcon chart2Icon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/chart2.png")));
        ImageIcon importIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/import.png")));
        ImageIcon exportIcon = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Resources/export.png")));

        // Dashboard
        Image img = dashboardIcon.getImage();
        Image img2 = img.getScaledInstance(DashboardImage.getWidth(), DashboardImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        DashboardImage.setIcon(i);

        // Courses
        img = coursesIcon.getImage();
        img2 = img.getScaledInstance(CoursesImage.getWidth(), CoursesImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        CoursesImage.setIcon(i);

        // Students
        img = studentsIcon.getImage();
        img2 = img.getScaledInstance(StudentsImage.getWidth(), StudentsImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        StudentsImage.setIcon(i);

        // Syllabus
        img = syllabusIcon.getImage();
        img2 = img.getScaledInstance(SyllabusImage.getWidth(), SyllabusImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        SyllabusImage.setIcon(i);

        // Exams
        img = examsIcon.getImage();
        img2 = img.getScaledInstance(ExamsImage.getWidth(), ExamsImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ExamsImage.setIcon(i);

        // Reports
        img = reportsIcon.getImage();
        img2 = img.getScaledInstance(ReportsImage.getWidth(), ReportsImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ReportsImage.setIcon(i);

        // Settings
        img = settingsIcon.getImage();
        img2 = img.getScaledInstance(SettingsImage.getWidth(), SettingsImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        SettingsImage.setIcon(i);

        // Chart1 inside main dashboard panel.
        img = chart1Icon.getImage();
        img2 = img.getScaledInstance(ChartImage1.getWidth(), ChartImage1.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ChartImage1.setIcon(i);

        // Chart2 inside main dashboard panel.
        img = chart2Icon.getImage();
        img2 = img.getScaledInstance(ChartImage2.getWidth(), ChartImage2.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ChartImage2.setIcon(i);

        // Import icon inside main dashboard panel.
        img = importIcon.getImage();
        img2 = img.getScaledInstance(ImportImage.getWidth(), ImportImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ImportImage.setIcon(i);

        // Import icon inside main dashboard panel.
        img = exportIcon.getImage();
        img2 = img.getScaledInstance(ExportImage.getWidth(), ExportImage.getHeight(), Image.SCALE_SMOOTH);
        i = new ImageIcon(img2);
        ExportImage.setIcon(i);

    }

    private void InitializeMenuBarItems()
    {
        // Create objects for menu bar items.
        MenuBarItem dashboard = new MenuBarItem(DashboardWrapper, DashboardMainPanel, null, null);
        MenuBarItem courses = new MenuBarItem(CoursesWrapper, CoursesMainPanel, null, null);
        MenuBarItem students = new MenuBarItem(StudentsWrapper, StudentsMainPanel, StudentsScrollPane, StudentsNoCoursePanel);
        MenuBarItem syllabus = new MenuBarItem(SyllabusWrapper, SyllabusMainPanel, SyllabusScrollPane, SyllabusNoCoursePanel);
        MenuBarItem exams = new MenuBarItem(ExamsWrapper, ExamsMainPanel, ExamsScrollPane, ExamsNoCoursePanel);
        MenuBarItem reports = new MenuBarItem(ReportsWrapper, ReportsMainPanel, ReportsScrollPane, ReportsNoCoursePanel);

        // Init list
        menuBarItems = new ArrayList<MenuBarItem>();

        // Init current selected menu
        currentSelectedMenu = null;

        // Add objets.
        menuBarItems.add(dashboard);
        menuBarItems.add(courses);
        menuBarItems.add(students);
        menuBarItems.add(syllabus);
        menuBarItems.add(exams);
        menuBarItems.add(reports);

        // Deselect all menus.
        DeselectAllMenu();

        // Select dashboard as initial menu.
        SelectMenu(dashboard);
    }

    private void AddComponentListeners()
    {

        MouseAdapterForMenu db = new MouseAdapterForMenu(0, this);
        MouseAdapterForMenu cs = new MouseAdapterForMenu(1, this);
        MouseAdapterForMenu st = new MouseAdapterForMenu(2, this);
        MouseAdapterForMenu syl = new MouseAdapterForMenu(3, this);
        MouseAdapterForMenu exm = new MouseAdapterForMenu(4, this);
        MouseAdapterForMenu rp = new MouseAdapterForMenu(5, this);

        // Add listeners to labels
        DashboardLabel.addMouseListener(db);
        CoursesLabel.addMouseListener(cs);
        StudentsLabel.addMouseListener(st);
        SyllabusLabel.addMouseListener(syl);
        ExamsLabel.addMouseListener(exm);
        ReportsLabel.addMouseListener(rp);

        // Add listeners to wrappers.
        DashboardWrapper.addMouseListener(db);
        CoursesWrapper.addMouseListener(cs);
        StudentsWrapper.addMouseListener(st);
        SyllabusWrapper.addMouseListener(syl);
        ExamsWrapper.addMouseListener(exm);
        ReportsWrapper.addMouseListener(rp);

        // Add listeners to images. (icons)
        DashboardImage.addMouseListener(db);
        CoursesImage.addMouseListener(cs);
        StudentsImage.addMouseListener(st);
        SyllabusImage.addMouseListener(syl);
        ExamsImage.addMouseListener(exm);
        ReportsImage.addMouseListener(rp);

    }

    private void SetUIChoices()
    {
        AddCourseWarning.setVisible(false);
        EditCourseWarning.setVisible(false);
        AddSectionWarning.setVisible(false);
        EditSectionWarning.setVisible(false);
        AddLOWarning.setVisible(false);
        SaveLOWarning.setVisible(false);
        FileFilter filter = new FileNameExtensionFilter("Excel (.XLSX)", "xlsx");
        FileChooser.setFileFilter(filter);
        FileChooser.setAcceptAllFileFilterUsed(false);
    }

    // 1 is for adding a new course, 2 is for removing.
    public void SetLastActionForCourses(Course subject, int actionIndex)
    {
        try
        {
            CourseAction c = new CourseAction(subject, actionIndex, CoursesList.getSelectedIndex());
            courseActions.add(c);
        }
        catch (ActionIndexException e)
        {
            return;
        }

        UndoButton.setEnabled(true);

    }

    public void SelectCourse(int course)
    {
        selectedCourse = course;

        if (selectedCourse != -1)
            SelectSection(courseManager.GetCourse(selectedCourse).getSelectedSectionIndex());
        else
            UpdateSections();

        // Update menus.
        UpdateCourseList();
        UpdateSyllabus();
        UpdateExams();
        UpdateReports();
    }

    public void SelectExam(int exam)
    {
        courseManager.GetCourse(selectedCourse).setSelectedExam(exam);
        UpdateExams();
        UpdateReports();
    }

    public void SelectQuestion(int question)
    {
        courseManager.GetCourse(selectedCourse).getSelectedExam().setSelectedQuestion(question);
        UpdateExams();
        UpdateReports();
    }

    public void SelectSection(int section)
    {
        if (selectedCourse != -1)
            courseManager.GetCourse(selectedCourse).setSection(section);

        UpdateSections();
        UpdateStudents();
        UpdateReports();
    }

    public void SelectSyllabusWeek(int week)
    {
        if (selectedCourse != -1)
            courseManager.GetCourse(selectedCourse).getSyllabus().setSelectedWeek(week);

        UpdateSyllabus();
        UpdateReports();
    }

    public void SelectLearningOutcome(int outcome)
    {
        if (selectedCourse != -1)
            courseManager.GetCourse(selectedCourse).getSyllabus().getSelectedLO(outcome);

        UpdateSyllabus();
        UpdateReports();
    }

    // Called from mouse adapters.
    public void SelectMenu(int barItemIndex)
    {
        SelectMenu(menuBarItems.get(barItemIndex));
    }

    public void SelectMenu(MenuBarItem menu)
    {
        // Deselect if current menu is not null.
        if (currentSelectedMenu != null)
            DeselectMenu(currentSelectedMenu);

        // Set selectable panel color to selected.
        menu.getSelectablePanel().setBackground(selectedMenuItemColor);

        // Enable menu's main panel.
        menu.getMainPanel().setVisible(true);
        menu.getMainPanel().setEnabled(true);

        // Set the visibility of no course panels and inner panels.
        if (menu.getNoCoursePanel() != null)
            menu.getNoCoursePanel().setVisible(selectedCourse == -1);

        if (menu.getInnerPanel() != null)
            menu.getInnerPanel().setVisible(selectedCourse != -1);

        // Set current selected.
        currentSelectedMenu = menu;

    }

    private void DeselectAllMenu()
    {
        for (int i = 0; i < menuBarItems.size(); i++)
            DeselectMenu(menuBarItems.get(i));
    }

    void DeselectMenu(MenuBarItem menu)
    {
        // Set selectable panel color to unselected.
        menu.getSelectablePanel().setBackground(unselectedMenuItemColor);

        // Disable menu's main panel.
        menu.getMainPanel().setVisible(false);
        menu.getMainPanel().setEnabled(false);
    }

    public void UpdateCourseList()
    {
        if (selectedCourse == -1)
        {
            // Disable buttons and empty the fields.
            DuplicateCourseButton.setEnabled(false);
            RemoveCourseButton.setEnabled(false);
            CourseID.setText("");
            CourseName.setText("");
            CourseDescription.setText("");
        }
        else
        {
            // Enable buttons and fill the fields.
            String id = courseManager.GetCourse(selectedCourse).getID();
            String name = courseManager.GetCourse(selectedCourse).getName();
            String desc = courseManager.GetCourse(selectedCourse).getDescription();
            DuplicateCourseButton.setEnabled(true);
            RemoveCourseButton.setEnabled(true);
            CourseID.setText(id);
            CourseName.setText(name);
            CourseDescription.setText(desc);
        }

        ArrayList<Course> courses = courseManager.GetCourseList();
        DefaultListModel courseListModel = new DefaultListModel();
        DefaultComboBoxModel courseComboBoxModel = new DefaultComboBoxModel();

        // Fill list & combobox model based on courses.
        for (int i = 0; i < courses.size(); i++)
        {
            String elementDisplay = (new StringBuilder()).append(courses.get(i).getID()).append(" - ").append(courses.get(i).getName()).toString();
            courseListModel.addElement(elementDisplay);
            courseComboBoxModel.addElement(elementDisplay);
        }

        // Set list & combobox model.
        CoursesList.setModel(courseListModel);
        CourseSelectionComboBox.setModel(courseComboBoxModel);
        CoursesList.setSelectedIndex(selectedCourse);
        CourseSelectionComboBox.setSelectedIndex(selectedCourse);

        courseManager.SaveCourses();
    }

    public void UpdateSections()
    {
        DefaultListModel m = new DefaultListModel();
        DefaultComboBoxModel cm = new DefaultComboBoxModel();

        if (selectedCourse != -1)
        {
            ArrayList<Section> sections = new ArrayList<Section>();
            sections = courseManager.GetCourse(selectedCourse).getSections();

            // Fill list & combobox models for sections.
            for (int i = 0; i < sections.size(); i++)
            {
                String elementDisplay = (new StringBuilder()).append(sections.get(i).GetName()).toString();
                m.addElement(elementDisplay);
                cm.addElement(elementDisplay);
            }

            // Adjust button activation.
            if (courseManager.GetCourse(selectedCourse).getSections().size() > 1)
                RemoveSectionButton.setEnabled(true);
            else
                RemoveSectionButton.setEnabled(false);

            AddSectionButton.setEnabled(true);

        }
        else
        {
            AddSectionButton.setEnabled(false);
            RemoveSectionButton.setEnabled(false);
        }

        // Set models.
        SectionsList.setModel(m);
        SectionSelectionComboBox.setModel(cm);

        // Set selection indices.
        int toSelect = selectedCourse == -1 ? -1 : courseManager.GetCourse(selectedCourse).getSelectedSectionIndex();
        SectionsList.setSelectedIndex(toSelect);
        SectionSelectionComboBox.setSelectedIndex(toSelect);

        courseManager.SaveCourses();
    }

    private void UpdateStudents()
    {
        if (selectedCourse == -1)
            return;

        ArrayList<Student> students = courseManager.GetCourse(selectedCourse).getSelectedSection().GetStudents();
        DefaultListModel studentsModel = new DefaultListModel();

        // Fill list model for students.
        for (int i = 0; i < students.size(); i++)
        {
            String elementDisplay = new StringBuilder().append(students.get(i).getID()).toString();
            studentsModel.addElement(elementDisplay);
        }

        // Set model, update and save.
        StudentList.setModel(studentsModel);
        UpdateReports();
        courseManager.SaveCourses();
    }

    private void UpdateExams()
    {
        if (selectedCourse == -1)
            return;

        int selectedExam = courseManager.GetCourse(selectedCourse).getSelectedExamIndex();
        ArrayList<Exam> exams = courseManager.GetCourse(selectedCourse).getExams();
        DefaultListModel examsModel = new DefaultListModel();

        // Fill list model for exams.
        for (int i = 0; i < exams.size(); i++)
        {
            String elementDisplay = new StringBuilder().append(exams.get(i).getType().toString()).toString();
            examsModel.addElement(elementDisplay);
        }

        // Set model and select index.
        ExamList.setModel(examsModel);
        ExamList.setSelectedIndex(selectedExam);

        if (selectedExam == -1)
        {
            // Disable buttons.
            RemoveExamButton.setEnabled(false);
            ExamEditPanel.setVisible(false);
        }
        else
        {
            // Enable buttons, adjust selection, dates and fields.
            RemoveExamButton.setEnabled(true);
            ExamEditPanel.setVisible(true);
            ExamTypeComboBox.setSelectedIndex(courseManager.GetCourse(selectedCourse).getSelectedExam().getType().getValue());
            ExamDateChooser.setDate(courseManager.GetCourse(selectedCourse).getSelectedExam().getDate());
            ExamPercentageField.setText(Integer.toString(courseManager.GetCourse(selectedCourse).getSelectedExam().getPercentage()));

            ArrayList<Question> questions = courseManager.GetCourse(selectedCourse).getSelectedExam().getQuestions();
            DefaultListModel questionsModel = new DefaultListModel();

            // Fill question list model.
            for (int i = 0; i < questions.size(); i++)
            {
                String elementDisplay = new StringBuilder().append("Question ").append(i).toString();
                questionsModel.addElement(elementDisplay);
            }

            // Set model and selection.
            QuestionList.setModel(questionsModel);
            QuestionList.setSelectedIndex(courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestionIndex());

            if (QuestionList.getSelectedIndex() != -1)
            {
                // Adjust buttons and fields.
                SelectLOButton.setEnabled(true);
                SelectTopicsButton.setEnabled(true);
                QuestionPointField.setEnabled(true);
                QuestionPointField.setText(Integer.toString(courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().getPoints()));

                // Fill model for topic list.
                ArrayList<Integer> topicIndices = courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().getTopicList();
                DefaultListModel topicsModel = new DefaultListModel();
                ArrayList<Week> weeks = courseManager.GetCourse(selectedCourse).getSyllabus().getWeeks();

                for (int i = 0; i < topicIndices.size(); i++)
                {
                    String name = weeks.get(topicIndices.get(i)).getTopic();
                    String elementDisplay = new StringBuilder().append("Week ").append(topicIndices.get(i)).append(" ").append(name).toString();
                    topicsModel.addElement(elementDisplay);
                }

                // Set model.
                ExamTopicList.setModel(topicsModel);

                // Set model for lo indices.
                ArrayList<Integer> loIndices = courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().getLOList();
                DefaultListModel loModel = new DefaultListModel();
                ArrayList<String> learningOutcomes = courseManager.GetCourse(selectedCourse).getSyllabus().getLearningOutcomes();

                for (int i = 0; i < loIndices.size(); i++)
                {
                    String name = learningOutcomes.get(loIndices.get(i));
                    loModel.addElement(name);
                }

                ExamLOList.setModel(loModel);

            }
            else
            {
                // Set empty models and disable buttons.
                ExamLOList.setModel(new DefaultListModel());
                ExamTopicList.setModel(new DefaultListModel());
                QuestionPointField.setEnabled(false);
                QuestionPointField.setText("");
                SelectLOButton.setEnabled(false);
                SelectTopicsButton.setEnabled(false);
            }
        }

        courseManager.SaveCourses();
    }

    private void UpdateReports()
    {
        if (selectedCourse == -1)
            return;

        // Fill model for student combobox.
        DefaultComboBoxModel cm = new DefaultComboBoxModel();
        ArrayList<Student> studentList = courseManager.GetCourse(selectedCourse).getSelectedSection().GetStudents();

        if (studentList.size() > 0)
        {
            // Must add all students manually.
            cm.addElement("ALL STUDENTS");

            // Fill model.
            for (int i = 0; i < studentList.size(); i++)
            {
                String id = studentList.get(i).getID();
                cm.addElement(id);
            }

            // Set model.
            AttendanceReportsComboBox.setModel(cm);
            ViewAttendanceReportButton.setEnabled(true);
        }
        else
        {
            // Set default model and disable button.
            AttendanceReportsComboBox.setModel(new DefaultComboBoxModel());
            ViewAttendanceReportButton.setEnabled(false);
        }

        // Enable & disable buttons based on current exams, weeks and questions.
        if (studentList.size() > 0 && courseManager.GetCourse(selectedCourse).getExams().size() > 0)
            ViewAttendanceReportExamsButton.setEnabled(true);
        else
            ViewAttendanceReportExamsButton.setEnabled(false);

        if (courseManager.GetCourse(selectedCourse).getExams().size() > 0 && courseManager.GetCourse(selectedCourse).getSyllabus().getWeeks().size() > 0
                && courseManager.GetCourse(selectedCourse).getSelectedExam().getQuestions().size() > 0)
        {
            ViewTopicSuccessButton.setEnabled(true);
            ViewExamGradesButton.setEnabled(true);
        }
        else
        {
            ViewExamGradesButton.setEnabled(false);
            ViewTopicSuccessButton.setEnabled(false);
        }

        courseManager.SaveCourses();
    }

    private void UpdateSyllabus()
    {
        // Set models to default and dates to null if no course is selected.
        if (selectedCourse == -1)
        {
            SyllabusStartDateChooser.setDate(null);
            SyllabusEndDateChooser.setDate(null);
            SyllabusWeekTopicsArea.setText("");
            SyllabusWeekList.setModel(new DefaultListModel());
            LearningOutcomeList.setModel(new DefaultListModel());
            return;
        }

        // Fill model for weeks.
        ArrayList<Week> weeks = courseManager.GetCourse(selectedCourse).getSyllabus().getWeeks();
        DefaultListModel syllabusWeeksModel = new DefaultListModel();

        for (int i = 0; i < weeks.size(); i++)
        {
            String elementDisplay = (new StringBuilder()).append("Week ").append((i + 1)).toString();
            syllabusWeeksModel.addElement(elementDisplay);
        }

        // Set model and selection for week list.
        SyllabusWeekList.setModel(syllabusWeeksModel);
        SyllabusWeekList.setSelectedIndex(courseManager.GetCourse(selectedCourse).getSyllabus().getSelectedWeek());

        // Set dates.
        Date start = courseManager.GetCourse(selectedCourse).getSyllabus().getStartDate();
        Date end = courseManager.GetCourse(selectedCourse).getSyllabus().getEndDate();
        SyllabusStartDateChooser.setDate(start);
        SyllabusEndDateChooser.setDate(end);

        // Cant select end date if start has not been select.
        if (start == null)
            SyllabusEndDateChooser.setEnabled(false);

        // Fill topics area.
        if (courseManager.GetCourse(selectedCourse).getSyllabus().getWeeks().size() > 0)
        {
            String topic = courseManager.GetCourse(selectedCourse).getSyllabus().getWeeks().get(0).getTopic();
            SyllabusWeekTopicsArea.setText(topic);
            SyllabusWeekTopicsArea.setEditable(true);
        }
        else
        {
            SyllabusWeekTopicsArea.setText("");
            SyllabusWeekTopicsArea.setEditable(false);
        }

        ArrayList<String> lo = courseManager.GetCourse(selectedCourse).getSyllabus().getLearningOutcomes();

        if (lo == null)
        {
            courseManager.SaveCourses();
            return;
        }

        // fill model for learning outcomes.
        DefaultListModel m = new DefaultListModel();
        for (int i = 0; i < lo.size(); i++)
        {
            String elementDisplay = (new StringBuilder()).append("L.O  ").append((i + 1) + ": ").append(lo.get(i)).toString();
            m.addElement(elementDisplay);
        }

        // Set model & selection index.
        LearningOutcomeList.setModel(m);
        int loIndex = courseManager.GetCourse(selectedCourse).getSyllabus().getSelectedLO();
        LearningOutcomeList.setSelectedIndex(loIndex);

        // Activation of remove button.
        if (loIndex == -1)
            RemoveLearningOutcomeButton.setEnabled(false);
        else
            RemoveLearningOutcomeButton.setEnabled(true);

        courseManager.SaveCourses();
    }

    private void DisposeAddNewCourseDialog()
    {
        // Reset components & dispose.
        AddCourseIDField.setText("");
        AddCourseNameField.setText("");
        AddCourseDescField.setText("");
        AddCourseWarning.setVisible(false);
        AddCourseAddButton.setEnabled(false);
        AddNewCourseDialog.dispose();
    }

    private void DisposeEditCourseDialog()
    {
        // Reset components & dispose.
        EditCourseIDField.setText("");
        EditCourseNameField.setText("");
        EditCourseDescField.setText("");
        EditCourseWarning.setVisible(false);
        EditCourseDialog.dispose();
    }

    private void DisposeAddSectionDialog()
    {
        // Reset components & dispose.
        AddSectionNameField.setText("");
        AddSectionWarning.setVisible(false);
        AddSectionAddButton.setEnabled(false);
        AddSectionDialog.dispose();
    }

    private void DisposeEditSectionDialog()
    {
        // Reset components & dispose.
        EditSectionNameField.setText("");
        EditSectionWarning.setVisible(false);
        EditSectionSaveButton.setEnabled(false);
        EditSectionDialog.dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EditCourseDialog = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        EditCourseID = new javax.swing.JLabel();
        EditCourseIDField = new javax.swing.JTextField();
        EditCourseName = new javax.swing.JLabel();
        EditCourseNameField = new javax.swing.JTextField();
        EditCourseDesc = new javax.swing.JLabel();
        EditCourseDescPane = new javax.swing.JScrollPane();
        EditCourseDescField = new javax.swing.JTextArea();
        EditCourseCancelButton = new javax.swing.JButton();
        EditCourseWarning = new javax.swing.JLabel();
        EditCourseSaveButton = new javax.swing.JButton();
        AddNewCourseDialog = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        AddCourseID = new javax.swing.JLabel();
        AddCourseIDField = new javax.swing.JTextField();
        AddCourseName = new javax.swing.JLabel();
        AddCourseNameField = new javax.swing.JTextField();
        AddCourseDesc = new javax.swing.JLabel();
        AddCourseDescPane = new javax.swing.JScrollPane();
        AddCourseDescField = new javax.swing.JTextArea();
        AddCourseCancelButton = new javax.swing.JButton();
        AddCourseWarning = new javax.swing.JLabel();
        AddCourseAddButton = new javax.swing.JButton();
        AddSectionDialog = new javax.swing.JDialog();
        jPanel10 = new javax.swing.JPanel();
        AddSectionName = new javax.swing.JLabel();
        AddSectionNameField = new javax.swing.JTextField();
        AddSectionCancelButton = new javax.swing.JButton();
        AddSectionWarning = new javax.swing.JLabel();
        AddSectionAddButton = new javax.swing.JButton();
        EditSectionDialog = new javax.swing.JDialog();
        jPanel11 = new javax.swing.JPanel();
        EditSectionName = new javax.swing.JLabel();
        EditSectionNameField = new javax.swing.JTextField();
        EditSectionCancel = new javax.swing.JButton();
        EditSectionWarning = new javax.swing.JLabel();
        EditSectionSaveButton = new javax.swing.JButton();
        AddLearningOutcomeDialog = new javax.swing.JDialog();
        jPanel13 = new javax.swing.JPanel();
        AddLOLabel = new javax.swing.JLabel();
        AddLOCancel = new javax.swing.JButton();
        AddLOAddButton = new javax.swing.JButton();
        AddLOWarning = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        AddLOTextField = new javax.swing.JTextArea();
        EditLearningOutcomeDialog = new javax.swing.JDialog();
        jPanel15 = new javax.swing.JPanel();
        SaveLOLabel = new javax.swing.JLabel();
        SaveLOCancel = new javax.swing.JButton();
        SaveLOSaveButton = new javax.swing.JButton();
        SaveLOWarning = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        SaveLOTextField = new javax.swing.JTextArea();
        SelectLODialog = new javax.swing.JDialog();
        jPanel17 = new javax.swing.JPanel();
        SelectLOListSelectButton = new javax.swing.JButton();
        jScrollPane14 = new javax.swing.JScrollPane();
        SelectLOList = new javax.swing.JList<>();
        SelectLOListCancelButton = new javax.swing.JButton();
        SelectLOListSelectEmptyButton = new javax.swing.JButton();
        SelectTopicDialog = new javax.swing.JDialog();
        jPanel18 = new javax.swing.JPanel();
        SelectTopicListSelectButton = new javax.swing.JButton();
        jScrollPane15 = new javax.swing.JScrollPane();
        SelectTopicList = new javax.swing.JList<>();
        SelectTopicListCancelButton = new javax.swing.JButton();
        SelectTopicListSelectEmptyButton = new javax.swing.JButton();
        FileChooser = new javax.swing.JFileChooser();
        Main = new javax.swing.JPanel();
        Left = new javax.swing.JPanel();
        MenuPanel = new javax.swing.JPanel();
        DashboardPanel = new javax.swing.JPanel();
        DashboardWrapper = new javax.swing.JPanel();
        DashboardImage = new javax.swing.JLabel();
        DashboardLabel = new javax.swing.JLabel();
        CoursesPanel = new javax.swing.JPanel();
        CoursesLabel = new javax.swing.JLabel();
        CoursesWrapper = new javax.swing.JPanel();
        CoursesImage = new javax.swing.JLabel();
        SyllabusPanel = new javax.swing.JPanel();
        SyllabusLabel = new javax.swing.JLabel();
        SyllabusWrapper = new javax.swing.JPanel();
        SyllabusImage = new javax.swing.JLabel();
        StudentsPanel = new javax.swing.JPanel();
        StudentsLabel = new javax.swing.JLabel();
        StudentsWrapper = new javax.swing.JPanel();
        StudentsImage = new javax.swing.JLabel();
        ExamsPanel = new javax.swing.JPanel();
        ExamsLabel = new javax.swing.JLabel();
        ExamsWrapper = new javax.swing.JPanel();
        ExamsImage = new javax.swing.JLabel();
        ReportsPanel = new javax.swing.JPanel();
        ReportsLabel = new javax.swing.JLabel();
        ReportsWrapper = new javax.swing.JPanel();
        ReportsImage = new javax.swing.JLabel();
        Top = new javax.swing.JPanel();
        TopCenter = new javax.swing.JPanel();
        SelectedCourseLabel = new javax.swing.JLabel();
        SelectedSectionLabel = new javax.swing.JLabel();
        SectionSelectionComboBox = new javax.swing.JComboBox<>();
        CourseSelectionComboBox = new javax.swing.JComboBox<>();
        TopLeft = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        SettingsImage = new javax.swing.JLabel();
        TopRight = new javax.swing.JPanel();
        Center = new javax.swing.JPanel();
        ExamsMainPanel = new javax.swing.JPanel();
        DBTitlePanel4 = new javax.swing.JPanel();
        DashboardMainTitle4 = new javax.swing.JLabel();
        CoursesMainPanel = new javax.swing.JPanel();
        CoursesTitlePanel = new javax.swing.JPanel();
        CoursesMainTitle = new javax.swing.JLabel();
        DashboardMainPanel = new javax.swing.JPanel();
        DBMain = new javax.swing.JPanel();
        SyllabusMainPanel = new javax.swing.JPanel();
        SyllabusTitlePanel = new javax.swing.JPanel();
        SyllabusMainTitle = new javax.swing.JLabel();
        SylMainPanel = new javax.swing.JPanel();
        SyllabusScrollPane = new javax.swing.JScrollPane();
        StudentsMainPanel = new javax.swing.JPanel();
        DBTitlePanel6 = new javax.swing.JPanel();
        StudentsMainTitle = new javax.swing.JLabel();
        StudentsMP = new javax.swing.JPanel();
        StudentsScrollPane = new javax.swing.JScrollPane();
        ReportsMainPanel = new javax.swing.JPanel();
        DBTitlePanel5 = new javax.swing.JPanel();
        DashboardMainTitle5 = new javax.swing.JLabel();
        ReportsMP = new javax.swing.JPanel();
        ReportsScrollPane = new javax.swing.JScrollPane();

        EditCourseDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        EditCourseDialog.setTitle("Add New Course");
        EditCourseDialog.setAlwaysOnTop(true);
        EditCourseDialog.setBackground(new java.awt.Color(26, 24, 26));
        EditCourseDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        EditCourseDialog.setModal(true);
        EditCourseDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(EditCourseDialog.getContentPane()));

        jPanel4.setBackground(new java.awt.Color(26, 24, 26));

        EditCourseID.setBackground(new java.awt.Color(26, 24, 26));
        EditCourseID.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditCourseID.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseID.setText("ID:");
        EditCourseID.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditCourseID.setPreferredSize(new java.awt.Dimension(100, 50));

        EditCourseIDField.setBackground(new java.awt.Color(26, 24, 26));
        EditCourseIDField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        EditCourseIDField.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseIDField.setCaretColor(new java.awt.Color(204, 204, 204));
        EditCourseIDField.setPreferredSize(new java.awt.Dimension(200, 40));
        EditCourseIDField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                EditCourseIDFieldKeyReleased(evt);
            }
        });

        EditCourseName.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditCourseName.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseName.setText("Name:");
        EditCourseName.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditCourseName.setPreferredSize(new java.awt.Dimension(100, 50));

        EditCourseNameField.setBackground(new java.awt.Color(26, 24, 26));
        EditCourseNameField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        EditCourseNameField.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseNameField.setCaretColor(new java.awt.Color(204, 204, 204));
        EditCourseNameField.setPreferredSize(new java.awt.Dimension(200, 40));

        EditCourseDesc.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditCourseDesc.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseDesc.setText("Description:");
        EditCourseDesc.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditCourseDesc.setMaximumSize(new java.awt.Dimension(121, 225));
        EditCourseDesc.setPreferredSize(new java.awt.Dimension(121, 225));

        EditCourseDescField.setBackground(new java.awt.Color(26, 24, 26));
        EditCourseDescField.setColumns(20);
        EditCourseDescField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        EditCourseDescField.setForeground(new java.awt.Color(227, 227, 227));
        EditCourseDescField.setLineWrap(true);
        EditCourseDescField.setRows(5);
        EditCourseDescField.setCaretColor(new java.awt.Color(204, 204, 204));
        EditCourseDescPane.setViewportView(EditCourseDescField);

        EditCourseCancelButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        EditCourseCancelButton.setText("Cancel");
        EditCourseCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditCourseCancelButtonActionPerformed(evt);
            }
        });

        EditCourseWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditCourseWarning.setForeground(new java.awt.Color(204, 0, 51));
        EditCourseWarning.setText("This Course Already Exists");
        EditCourseWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditCourseWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        EditCourseSaveButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        EditCourseSaveButton.setText("Save");
        EditCourseSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditCourseSaveButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(EditCourseSaveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditCourseDesc, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                    .addComponent(EditCourseName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditCourseID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(EditCourseCancelButton)
                        .addGap(34, 34, 34)
                        .addComponent(EditCourseWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 198, Short.MAX_VALUE))
                    .addComponent(EditCourseDescPane)
                    .addComponent(EditCourseIDField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditCourseNameField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EditCourseIDField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditCourseNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EditCourseName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(EditCourseDescPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(EditCourseDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditCourseSaveButton)
                    .addComponent(EditCourseCancelButton)
                    .addComponent(EditCourseWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        EditCourseDialog.getContentPane().add(jPanel4);

        AddNewCourseDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        AddNewCourseDialog.setTitle("Add New Course");
        AddNewCourseDialog.setAlwaysOnTop(true);
        AddNewCourseDialog.setBackground(new java.awt.Color(26, 24, 26));
        AddNewCourseDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        AddNewCourseDialog.setModal(true);
        AddNewCourseDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(AddNewCourseDialog.getContentPane()));

        jPanel1.setBackground(new java.awt.Color(26, 24, 26));

        AddCourseID.setBackground(new java.awt.Color(26, 24, 26));
        AddCourseID.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddCourseID.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseID.setText("ID:");
        AddCourseID.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddCourseID.setPreferredSize(new java.awt.Dimension(100, 50));

        AddCourseIDField.setBackground(new java.awt.Color(26, 24, 26));
        AddCourseIDField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        AddCourseIDField.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseIDField.setCaretColor(new java.awt.Color(204, 204, 204));
        AddCourseIDField.setPreferredSize(new java.awt.Dimension(200, 40));
        AddCourseIDField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                AddCourseIDFieldKeyReleased(evt);
            }
        });

        AddCourseName.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddCourseName.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseName.setText("Name:");
        AddCourseName.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddCourseName.setPreferredSize(new java.awt.Dimension(100, 50));

        AddCourseNameField.setBackground(new java.awt.Color(26, 24, 26));
        AddCourseNameField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        AddCourseNameField.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseNameField.setCaretColor(new java.awt.Color(204, 204, 204));
        AddCourseNameField.setPreferredSize(new java.awt.Dimension(200, 40));

        AddCourseDesc.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddCourseDesc.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseDesc.setText("Description:");
        AddCourseDesc.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddCourseDesc.setMaximumSize(new java.awt.Dimension(121, 225));
        AddCourseDesc.setPreferredSize(new java.awt.Dimension(121, 225));

        AddCourseDescField.setBackground(new java.awt.Color(26, 24, 26));
        AddCourseDescField.setColumns(20);
        AddCourseDescField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        AddCourseDescField.setForeground(new java.awt.Color(227, 227, 227));
        AddCourseDescField.setLineWrap(true);
        AddCourseDescField.setRows(5);
        AddCourseDescField.setCaretColor(new java.awt.Color(204, 204, 204));
        AddCourseDescPane.setViewportView(AddCourseDescField);

        AddCourseCancelButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddCourseCancelButton.setText("Cancel");
        AddCourseCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCourseCancelButtonActionPerformed(evt);
            }
        });

        AddCourseWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddCourseWarning.setForeground(new java.awt.Color(204, 0, 51));
        AddCourseWarning.setText("This Course Already Exists");
        AddCourseWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddCourseWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        AddCourseAddButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddCourseAddButton.setText("Add Course");
        AddCourseAddButton.setEnabled(false);
        AddCourseAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCourseAddButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddCourseAddButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddCourseDesc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddCourseName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddCourseID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(AddCourseCancelButton)
                        .addGap(34, 34, 34)
                        .addComponent(AddCourseWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 193, Short.MAX_VALUE))
                    .addComponent(AddCourseDescPane)
                    .addComponent(AddCourseIDField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddCourseNameField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddCourseIDField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddCourseNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddCourseName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(AddCourseDescPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(AddCourseDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddCourseAddButton)
                    .addComponent(AddCourseCancelButton)
                    .addComponent(AddCourseWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        AddNewCourseDialog.getContentPane().add(jPanel1);

        AddSectionDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        AddSectionDialog.setTitle("Add New Course");
        AddSectionDialog.setAlwaysOnTop(true);
        AddSectionDialog.setBackground(new java.awt.Color(26, 24, 26));
        AddSectionDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        AddSectionDialog.setModal(true);
        AddSectionDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(AddSectionDialog.getContentPane()));

        jPanel10.setBackground(new java.awt.Color(26, 24, 26));

        AddSectionName.setBackground(new java.awt.Color(26, 24, 26));
        AddSectionName.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddSectionName.setForeground(new java.awt.Color(227, 227, 227));
        AddSectionName.setText("Name:");
        AddSectionName.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddSectionName.setPreferredSize(new java.awt.Dimension(100, 50));

        AddSectionNameField.setBackground(new java.awt.Color(26, 24, 26));
        AddSectionNameField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        AddSectionNameField.setForeground(new java.awt.Color(227, 227, 227));
        AddSectionNameField.setCaretColor(new java.awt.Color(204, 204, 204));
        AddSectionNameField.setPreferredSize(new java.awt.Dimension(200, 40));
        AddSectionNameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                AddSectionNameFieldKeyReleased(evt);
            }
        });

        AddSectionCancelButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddSectionCancelButton.setText("Cancel");
        AddSectionCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSectionCancelButtonActionPerformed(evt);
            }
        });

        AddSectionWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddSectionWarning.setForeground(new java.awt.Color(204, 0, 51));
        AddSectionWarning.setText("This Section Already Exists!");
        AddSectionWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddSectionWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        AddSectionAddButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddSectionAddButton.setText("Add Section");
        AddSectionAddButton.setEnabled(false);
        AddSectionAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSectionAddButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddSectionAddButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddSectionName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(AddSectionCancelButton)
                        .addGap(34, 34, 34)
                        .addComponent(AddSectionWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(AddSectionNameField, javax.swing.GroupLayout.DEFAULT_SIZE, 709, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddSectionName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddSectionNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddSectionAddButton)
                    .addComponent(AddSectionCancelButton)
                    .addComponent(AddSectionWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        AddSectionDialog.getContentPane().add(jPanel10);

        EditSectionDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        EditSectionDialog.setTitle("Add New Course");
        EditSectionDialog.setAlwaysOnTop(true);
        EditSectionDialog.setBackground(new java.awt.Color(26, 24, 26));
        EditSectionDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        EditSectionDialog.setModal(true);
        EditSectionDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(EditSectionDialog.getContentPane()));

        jPanel11.setBackground(new java.awt.Color(26, 24, 26));

        EditSectionName.setBackground(new java.awt.Color(26, 24, 26));
        EditSectionName.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditSectionName.setForeground(new java.awt.Color(227, 227, 227));
        EditSectionName.setText("Name:");
        EditSectionName.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditSectionName.setPreferredSize(new java.awt.Dimension(100, 50));

        EditSectionNameField.setBackground(new java.awt.Color(26, 24, 26));
        EditSectionNameField.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        EditSectionNameField.setForeground(new java.awt.Color(227, 227, 227));
        EditSectionNameField.setCaretColor(new java.awt.Color(204, 204, 204));
        EditSectionNameField.setPreferredSize(new java.awt.Dimension(200, 40));
        EditSectionNameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                EditSectionNameFieldKeyReleased(evt);
            }
        });

        EditSectionCancel.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        EditSectionCancel.setText("Cancel");
        EditSectionCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditSectionCancelActionPerformed(evt);
            }
        });

        EditSectionWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        EditSectionWarning.setForeground(new java.awt.Color(204, 0, 51));
        EditSectionWarning.setText("This Section Already Exists!");
        EditSectionWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditSectionWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        EditSectionSaveButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        EditSectionSaveButton.setText("Save Section");
        EditSectionSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditSectionSaveButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(EditSectionSaveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditSectionName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(EditSectionCancel)
                        .addGap(34, 34, 34)
                        .addComponent(EditSectionWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(EditSectionNameField, javax.swing.GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditSectionName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EditSectionNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditSectionSaveButton)
                    .addComponent(EditSectionCancel)
                    .addComponent(EditSectionWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        EditSectionDialog.getContentPane().add(jPanel11);

        AddLearningOutcomeDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        AddLearningOutcomeDialog.setTitle("Add New Course");
        AddLearningOutcomeDialog.setAlwaysOnTop(true);
        AddLearningOutcomeDialog.setBackground(new java.awt.Color(26, 24, 26));
        AddLearningOutcomeDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        AddLearningOutcomeDialog.setModal(true);
        AddLearningOutcomeDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(AddLearningOutcomeDialog.getContentPane()));

        jPanel13.setBackground(new java.awt.Color(26, 24, 26));

        AddLOLabel.setBackground(new java.awt.Color(26, 24, 26));
        AddLOLabel.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddLOLabel.setForeground(new java.awt.Color(227, 227, 227));
        AddLOLabel.setText("Outcome:");
        AddLOLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddLOLabel.setPreferredSize(new java.awt.Dimension(100, 50));

        AddLOCancel.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddLOCancel.setText("Cancel");
        AddLOCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddLOCancelActionPerformed(evt);
            }
        });

        AddLOAddButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        AddLOAddButton.setText("Add");
        AddLOAddButton.setEnabled(false);
        AddLOAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddLOAddButtonActionPerformed(evt);
            }
        });

        AddLOWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        AddLOWarning.setForeground(new java.awt.Color(204, 0, 51));
        AddLOWarning.setText("Can not add empty field.");
        AddLOWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AddLOWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        AddLOTextField.setBackground(new java.awt.Color(26, 24, 26));
        AddLOTextField.setColumns(20);
        AddLOTextField.setFont(new java.awt.Font("Monospaced", 1, 16)); // NOI18N
        AddLOTextField.setForeground(new java.awt.Color(227, 227, 227));
        AddLOTextField.setLineWrap(true);
        AddLOTextField.setRows(5);
        AddLOTextField.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                AddLOTextFieldCaretUpdate(evt);
            }
        });
        jScrollPane9.setViewportView(AddLOTextField);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddLOAddButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddLOLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE))
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(AddLOCancel)
                        .addGap(44, 44, 44)
                        .addComponent(AddLOWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(39, Short.MAX_VALUE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane9)
                        .addContainerGap())))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                        .addGap(25, 25, 25))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(AddLOLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddLOCancel)
                    .addComponent(AddLOAddButton)
                    .addComponent(AddLOWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        AddLearningOutcomeDialog.getContentPane().add(jPanel13);

        EditLearningOutcomeDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        EditLearningOutcomeDialog.setTitle("Add New Course");
        EditLearningOutcomeDialog.setAlwaysOnTop(true);
        EditLearningOutcomeDialog.setBackground(new java.awt.Color(26, 24, 26));
        EditLearningOutcomeDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        EditLearningOutcomeDialog.setModal(true);
        EditLearningOutcomeDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(EditLearningOutcomeDialog.getContentPane()));

        jPanel15.setBackground(new java.awt.Color(26, 24, 26));

        SaveLOLabel.setBackground(new java.awt.Color(26, 24, 26));
        SaveLOLabel.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        SaveLOLabel.setForeground(new java.awt.Color(227, 227, 227));
        SaveLOLabel.setText("Outcome:");
        SaveLOLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        SaveLOLabel.setPreferredSize(new java.awt.Dimension(100, 50));

        SaveLOCancel.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SaveLOCancel.setText("Cancel");
        SaveLOCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveLOCancelActionPerformed(evt);
            }
        });

        SaveLOSaveButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SaveLOSaveButton.setText("Save");
        SaveLOSaveButton.setEnabled(false);
        SaveLOSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveLOSaveButtonActionPerformed(evt);
            }
        });

        SaveLOWarning.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        SaveLOWarning.setForeground(new java.awt.Color(204, 0, 51));
        SaveLOWarning.setText("Can not save empty field.");
        SaveLOWarning.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        SaveLOWarning.setPreferredSize(new java.awt.Dimension(121, 125));

        SaveLOTextField.setBackground(new java.awt.Color(26, 24, 26));
        SaveLOTextField.setColumns(20);
        SaveLOTextField.setFont(new java.awt.Font("Monospaced", 1, 16)); // NOI18N
        SaveLOTextField.setForeground(new java.awt.Color(227, 227, 227));
        SaveLOTextField.setLineWrap(true);
        SaveLOTextField.setRows(5);
        SaveLOTextField.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                SaveLOTextFieldCaretUpdate(evt);
            }
        });
        jScrollPane5.setViewportView(SaveLOTextField);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SaveLOSaveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SaveLOLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(SaveLOCancel)
                        .addGap(44, 44, 44)
                        .addComponent(SaveLOWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane5))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(SaveLOLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(25, 25, 25)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SaveLOCancel)
                    .addComponent(SaveLOSaveButton)
                    .addComponent(SaveLOWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        EditLearningOutcomeDialog.getContentPane().add(jPanel15);

        SelectLODialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        SelectLODialog.setTitle("Add New Course");
        SelectLODialog.setAlwaysOnTop(true);
        SelectLODialog.setBackground(new java.awt.Color(26, 24, 26));
        SelectLODialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        SelectLODialog.setModal(true);
        SelectLODialog.getContentPane().setLayout(new javax.swing.OverlayLayout(SelectLODialog.getContentPane()));

        jPanel17.setBackground(new java.awt.Color(26, 24, 26));

        SelectLOListSelectButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectLOListSelectButton.setText("Select");
        SelectLOListSelectButton.setEnabled(false);
        SelectLOListSelectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectLOListSelectButtonActionPerformed(evt);
            }
        });

        SelectLOList.setBackground(new java.awt.Color(26, 24, 26));
        SelectLOList.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        SelectLOList.setForeground(new java.awt.Color(227, 227, 227));
        SelectLOList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                SelectLOListMouseReleased(evt);
            }
        });
        jScrollPane14.setViewportView(SelectLOList);

        SelectLOListCancelButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectLOListCancelButton.setText("Cancel");
        SelectLOListCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectLOListCancelButtonActionPerformed(evt);
            }
        });

        SelectLOListSelectEmptyButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectLOListSelectEmptyButton.setText("Select Empty");
        SelectLOListSelectEmptyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectLOListSelectEmptyButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane14)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(SelectLOListSelectButton)
                        .addGap(18, 18, 18)
                        .addComponent(SelectLOListSelectEmptyButton)
                        .addGap(18, 18, 18)
                        .addComponent(SelectLOListCancelButton)
                        .addGap(0, 51, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelectLOListSelectButton)
                    .addComponent(SelectLOListCancelButton)
                    .addComponent(SelectLOListSelectEmptyButton))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        SelectLODialog.getContentPane().add(jPanel17);

        SelectTopicDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        SelectTopicDialog.setTitle("Add New Course");
        SelectTopicDialog.setAlwaysOnTop(true);
        SelectTopicDialog.setBackground(new java.awt.Color(26, 24, 26));
        SelectTopicDialog.setBounds(new java.awt.Rectangle(0, 0, 800, 600));
        SelectTopicDialog.setModal(true);
        SelectTopicDialog.getContentPane().setLayout(new javax.swing.OverlayLayout(SelectTopicDialog.getContentPane()));

        jPanel18.setBackground(new java.awt.Color(26, 24, 26));

        SelectTopicListSelectButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectTopicListSelectButton.setText("Select");
        SelectTopicListSelectButton.setEnabled(false);
        SelectTopicListSelectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectTopicListSelectButtonActionPerformed(evt);
            }
        });

        SelectTopicList.setBackground(new java.awt.Color(26, 24, 26));
        SelectTopicList.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        SelectTopicList.setForeground(new java.awt.Color(227, 227, 227));
        SelectTopicList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                SelectTopicListMouseReleased(evt);
            }
        });
        jScrollPane15.setViewportView(SelectTopicList);

        SelectTopicListCancelButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectTopicListCancelButton.setText("Cancel");
        SelectTopicListCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectTopicListCancelButtonActionPerformed(evt);
            }
        });

        SelectTopicListSelectEmptyButton.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        SelectTopicListSelectEmptyButton.setText("Select Empty");
        SelectTopicListSelectEmptyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectTopicListSelectEmptyButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 522, Short.MAX_VALUE)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(SelectTopicListSelectButton)
                        .addGap(18, 18, 18)
                        .addComponent(SelectTopicListSelectEmptyButton)
                        .addGap(18, 18, 18)
                        .addComponent(SelectTopicListCancelButton)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelectTopicListSelectButton)
                    .addComponent(SelectTopicListCancelButton)
                    .addComponent(SelectTopicListSelectEmptyButton))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        SelectTopicDialog.getContentPane().add(jPanel18);

        FileChooser.setControlButtonsAreShown(false);
        FileChooser.setCurrentDirectory(new java.io.File("/\"user.dir\""));
        FileChooser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FileChooserActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tina Analyzer");
        setBackground(new java.awt.Color(30, 30, 32));
        setMaximumSize(new java.awt.Dimension(2147483647, 1024));
        setPreferredSize(new java.awt.Dimension(1024, 768));

        Main.setBackground(new java.awt.Color(40, 41, 45));
        Main.setPreferredSize(new java.awt.Dimension(800, 600));
        Main.setLayout(new java.awt.BorderLayout());

        Left.setBackground(new java.awt.Color(40, 41, 45));
        Left.setMaximumSize(new java.awt.Dimension(250, 32767));
        Left.setPreferredSize(new java.awt.Dimension(250, 0));

        MenuPanel.setLayout(new javax.swing.BoxLayout(MenuPanel, javax.swing.BoxLayout.Y_AXIS));

        DashboardPanel.setBackground(new java.awt.Color(40, 41, 45));
        DashboardPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        DashboardWrapper.setBackground(new java.awt.Color(53, 55, 61));

        DashboardImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        DashboardImage.setForeground(new java.awt.Color(255, 255, 255));
        DashboardImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        DashboardImage.setToolTipText("");

        javax.swing.GroupLayout DashboardWrapperLayout = new javax.swing.GroupLayout(DashboardWrapper);
        DashboardWrapper.setLayout(DashboardWrapperLayout);
        DashboardWrapperLayout.setHorizontalGroup(
            DashboardWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        DashboardWrapperLayout.setVerticalGroup(
            DashboardWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        DashboardLabel.setBackground(new java.awt.Color(199, 50, 38));
        DashboardLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        DashboardLabel.setForeground(new java.awt.Color(227, 227, 227));
        DashboardLabel.setText("Dashboard");

        javax.swing.GroupLayout DashboardPanelLayout = new javax.swing.GroupLayout(DashboardPanel);
        DashboardPanel.setLayout(DashboardPanelLayout);
        DashboardPanelLayout.setHorizontalGroup(
            DashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(DashboardWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(DashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        DashboardPanelLayout.setVerticalGroup(
            DashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DashboardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(DashboardWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(DashboardPanelLayout.createSequentialGroup()
                        .addComponent(DashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MenuPanel.add(DashboardPanel);

        CoursesPanel.setBackground(new java.awt.Color(40, 41, 45));
        CoursesPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        CoursesLabel.setBackground(new java.awt.Color(199, 50, 38));
        CoursesLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        CoursesLabel.setForeground(new java.awt.Color(227, 227, 227));
        CoursesLabel.setText("Courses");

        CoursesWrapper.setBackground(new java.awt.Color(53, 55, 61));

        CoursesImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        CoursesImage.setForeground(new java.awt.Color(255, 255, 255));
        CoursesImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        CoursesImage.setToolTipText("");

        javax.swing.GroupLayout CoursesWrapperLayout = new javax.swing.GroupLayout(CoursesWrapper);
        CoursesWrapper.setLayout(CoursesWrapperLayout);
        CoursesWrapperLayout.setHorizontalGroup(
            CoursesWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CoursesImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        CoursesWrapperLayout.setVerticalGroup(
            CoursesWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CoursesImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout CoursesPanelLayout = new javax.swing.GroupLayout(CoursesPanel);
        CoursesPanel.setLayout(CoursesPanelLayout);
        CoursesPanelLayout.setHorizontalGroup(
            CoursesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(CoursesWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CoursesLabel)
                .addContainerGap(62, Short.MAX_VALUE))
        );
        CoursesPanelLayout.setVerticalGroup(
            CoursesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CoursesPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(CoursesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CoursesWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CoursesPanelLayout.createSequentialGroup()
                        .addComponent(CoursesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addContainerGap())
        );

        MenuPanel.add(CoursesPanel);

        SyllabusPanel.setBackground(new java.awt.Color(40, 41, 45));
        SyllabusPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        SyllabusLabel.setBackground(new java.awt.Color(199, 50, 38));
        SyllabusLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        SyllabusLabel.setForeground(new java.awt.Color(227, 227, 227));
        SyllabusLabel.setText("Syllabus");

        SyllabusWrapper.setBackground(new java.awt.Color(53, 55, 61));

        SyllabusImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        SyllabusImage.setForeground(new java.awt.Color(255, 255, 255));
        SyllabusImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        SyllabusImage.setToolTipText("");

        javax.swing.GroupLayout SyllabusWrapperLayout = new javax.swing.GroupLayout(SyllabusWrapper);
        SyllabusWrapper.setLayout(SyllabusWrapperLayout);
        SyllabusWrapperLayout.setHorizontalGroup(
            SyllabusWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SyllabusImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        SyllabusWrapperLayout.setVerticalGroup(
            SyllabusWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SyllabusImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout SyllabusPanelLayout = new javax.swing.GroupLayout(SyllabusPanel);
        SyllabusPanel.setLayout(SyllabusPanelLayout);
        SyllabusPanelLayout.setHorizontalGroup(
            SyllabusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(SyllabusWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SyllabusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 32, Short.MAX_VALUE))
        );
        SyllabusPanelLayout.setVerticalGroup(
            SyllabusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SyllabusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SyllabusWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(SyllabusPanelLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(SyllabusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MenuPanel.add(SyllabusPanel);

        StudentsPanel.setBackground(new java.awt.Color(40, 41, 45));
        StudentsPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        StudentsLabel.setBackground(new java.awt.Color(199, 50, 38));
        StudentsLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        StudentsLabel.setForeground(new java.awt.Color(227, 227, 227));
        StudentsLabel.setText("Students");

        StudentsWrapper.setBackground(new java.awt.Color(53, 55, 61));

        StudentsImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        StudentsImage.setForeground(new java.awt.Color(255, 255, 255));
        StudentsImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        StudentsImage.setToolTipText("");

        javax.swing.GroupLayout StudentsWrapperLayout = new javax.swing.GroupLayout(StudentsWrapper);
        StudentsWrapper.setLayout(StudentsWrapperLayout);
        StudentsWrapperLayout.setHorizontalGroup(
            StudentsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StudentsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(StudentsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        StudentsWrapperLayout.setVerticalGroup(
            StudentsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StudentsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(StudentsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout StudentsPanelLayout = new javax.swing.GroupLayout(StudentsPanel);
        StudentsPanel.setLayout(StudentsPanelLayout);
        StudentsPanelLayout.setHorizontalGroup(
            StudentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StudentsPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(StudentsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(StudentsLabel)
                .addContainerGap(51, Short.MAX_VALUE))
        );
        StudentsPanelLayout.setVerticalGroup(
            StudentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, StudentsPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(StudentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(StudentsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, StudentsPanelLayout.createSequentialGroup()
                        .addComponent(StudentsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addContainerGap())
        );

        MenuPanel.add(StudentsPanel);

        ExamsPanel.setBackground(new java.awt.Color(40, 41, 45));
        ExamsPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        ExamsLabel.setBackground(new java.awt.Color(199, 50, 38));
        ExamsLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        ExamsLabel.setForeground(new java.awt.Color(227, 227, 227));
        ExamsLabel.setText("Exams");

        ExamsWrapper.setBackground(new java.awt.Color(53, 55, 61));

        ExamsImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ExamsImage.setForeground(new java.awt.Color(255, 255, 255));
        ExamsImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        ExamsImage.setToolTipText("");

        javax.swing.GroupLayout ExamsWrapperLayout = new javax.swing.GroupLayout(ExamsWrapper);
        ExamsWrapper.setLayout(ExamsWrapperLayout);
        ExamsWrapperLayout.setHorizontalGroup(
            ExamsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ExamsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExamsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        ExamsWrapperLayout.setVerticalGroup(
            ExamsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ExamsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExamsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout ExamsPanelLayout = new javax.swing.GroupLayout(ExamsPanel);
        ExamsPanel.setLayout(ExamsPanelLayout);
        ExamsPanelLayout.setHorizontalGroup(
            ExamsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ExamsPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(ExamsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ExamsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 68, Short.MAX_VALUE))
        );
        ExamsPanelLayout.setVerticalGroup(
            ExamsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ExamsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ExamsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ExamsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ExamsPanelLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(ExamsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MenuPanel.add(ExamsPanel);

        ReportsPanel.setBackground(new java.awt.Color(40, 41, 45));
        ReportsPanel.setPreferredSize(new java.awt.Dimension(286, 70));

        ReportsLabel.setBackground(new java.awt.Color(199, 50, 38));
        ReportsLabel.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        ReportsLabel.setForeground(new java.awt.Color(227, 227, 227));
        ReportsLabel.setText("Reports");

        ReportsWrapper.setBackground(new java.awt.Color(53, 55, 61));

        ReportsImage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ReportsImage.setForeground(new java.awt.Color(255, 255, 255));
        ReportsImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/courses.png"))); // NOI18N
        ReportsImage.setToolTipText("");

        javax.swing.GroupLayout ReportsWrapperLayout = new javax.swing.GroupLayout(ReportsWrapper);
        ReportsWrapper.setLayout(ReportsWrapperLayout);
        ReportsWrapperLayout.setHorizontalGroup(
            ReportsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ReportsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        ReportsWrapperLayout.setVerticalGroup(
            ReportsWrapperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportsWrapperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ReportsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout ReportsPanelLayout = new javax.swing.GroupLayout(ReportsPanel);
        ReportsPanel.setLayout(ReportsPanelLayout);
        ReportsPanelLayout.setHorizontalGroup(
            ReportsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportsPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(ReportsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ReportsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 44, Short.MAX_VALUE))
        );
        ReportsPanelLayout.setVerticalGroup(
            ReportsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ReportsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ReportsWrapper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ReportsPanelLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(ReportsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MenuPanel.add(ReportsPanel);

        javax.swing.GroupLayout LeftLayout = new javax.swing.GroupLayout(Left);
        Left.setLayout(LeftLayout);
        LeftLayout.setHorizontalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftLayout.createSequentialGroup()
                .addComponent(MenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 20, Short.MAX_VALUE))
        );
        LeftLayout.setVerticalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(MenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(494, Short.MAX_VALUE))
        );

        Main.add(Left, java.awt.BorderLayout.WEST);

        Top.setBackground(new java.awt.Color(40, 41, 45));
        Top.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Top.setPreferredSize(new java.awt.Dimension(1064, 100));
        Top.setLayout(new java.awt.BorderLayout());

        TopCenter.setBackground(new java.awt.Color(40, 41, 45));
        TopCenter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TopCenter.setMaximumSize(new java.awt.Dimension(250, 32767));
        TopCenter.setRequestFocusEnabled(false);

        SelectedCourseLabel.setBackground(new java.awt.Color(199, 50, 38));
        SelectedCourseLabel.setFont(new java.awt.Font("Prototype", 0, 18)); // NOI18N
        SelectedCourseLabel.setForeground(new java.awt.Color(227, 227, 227));
        SelectedCourseLabel.setText("Selected Course:");
        SelectedCourseLabel.setToolTipText("");

        SelectedSectionLabel.setBackground(new java.awt.Color(199, 50, 38));
        SelectedSectionLabel.setFont(new java.awt.Font("Prototype", 0, 18)); // NOI18N
        SelectedSectionLabel.setForeground(new java.awt.Color(227, 227, 227));
        SelectedSectionLabel.setText("Section:");
        SelectedSectionLabel.setToolTipText("");

        SectionSelectionComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SectionSelectionComboBoxActionPerformed(evt);
            }
        });

        CourseSelectionComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CourseSelectionComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TopCenterLayout = new javax.swing.GroupLayout(TopCenter);
        TopCenter.setLayout(TopCenterLayout);
        TopCenterLayout.setHorizontalGroup(
            TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopCenterLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SelectedCourseLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SelectedSectionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(56, 56, 56)
                .addGroup(TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CourseSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SectionSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        TopCenterLayout.setVerticalGroup(
            TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopCenterLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelectedCourseLabel)
                    .addComponent(CourseSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(TopCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelectedSectionLabel)
                    .addComponent(SectionSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        Top.add(TopCenter, java.awt.BorderLayout.CENTER);

        TopLeft.setBackground(new java.awt.Color(40, 41, 45));
        TopLeft.setMaximumSize(new java.awt.Dimension(250, 32767));
        TopLeft.setPreferredSize(new java.awt.Dimension(250, 73));

        Title.setBackground(new java.awt.Color(217, 203, 158));
        Title.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        Title.setForeground(new java.awt.Color(238, 239, 247));
        Title.setLabelFor(TopLeft);
        Title.setText("Tina Analyzer");
        Title.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Title.setDoubleBuffered(true);

        SettingsImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/settings.png"))); // NOI18N

        javax.swing.GroupLayout TopLeftLayout = new javax.swing.GroupLayout(TopLeft);
        TopLeft.setLayout(TopLeftLayout);
        TopLeftLayout.setHorizontalGroup(
            TopLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopLeftLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(Title)
                .addGap(18, 18, 18)
                .addComponent(SettingsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        TopLeftLayout.setVerticalGroup(
            TopLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopLeftLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(TopLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Title)
                    .addComponent(SettingsImage, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        Top.add(TopLeft, java.awt.BorderLayout.WEST);

        TopRight.setBackground(new java.awt.Color(40, 41, 45));
        TopRight.setMaximumSize(new java.awt.Dimension(250, 32767));
        TopRight.setPreferredSize(new java.awt.Dimension(250, 73));

        javax.swing.GroupLayout TopRightLayout = new javax.swing.GroupLayout(TopRight);
        TopRight.setLayout(TopRightLayout);
        TopRightLayout.setHorizontalGroup(
            TopRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        TopRightLayout.setVerticalGroup(
            TopRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        Top.add(TopRight, java.awt.BorderLayout.EAST);

        Main.add(Top, java.awt.BorderLayout.NORTH);

        Center.setBackground(new java.awt.Color(26, 24, 26));
        Center.setLayout(new javax.swing.OverlayLayout(Center));

        ExamsMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        ExamsMainPanel.setLayout(new java.awt.BorderLayout());

        DBTitlePanel4.setBackground(new java.awt.Color(26, 24, 26));
        DBTitlePanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        DashboardMainTitle4.setBackground(new java.awt.Color(199, 50, 38));
        DashboardMainTitle4.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        DashboardMainTitle4.setForeground(new java.awt.Color(227, 227, 227));
        DashboardMainTitle4.setText("Exams");
        DashboardMainTitle4.setToolTipText("");

        javax.swing.GroupLayout DBTitlePanel4Layout = new javax.swing.GroupLayout(DBTitlePanel4);
        DBTitlePanel4.setLayout(DBTitlePanel4Layout);
        DBTitlePanel4Layout.setHorizontalGroup(
            DBTitlePanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardMainTitle4)
                .addContainerGap(925, Short.MAX_VALUE))
        );
        DBTitlePanel4Layout.setVerticalGroup(
            DBTitlePanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardMainTitle4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        ExamsMainPanel.add(DBTitlePanel4, java.awt.BorderLayout.NORTH);

        Center.add(ExamsMainPanel);

        CoursesMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        CoursesMainPanel.setLayout(new java.awt.BorderLayout(5, 25));

        CoursesTitlePanel.setBackground(new java.awt.Color(26, 24, 26));
        CoursesTitlePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        CoursesMainTitle.setBackground(new java.awt.Color(199, 50, 38));
        CoursesMainTitle.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        CoursesMainTitle.setForeground(new java.awt.Color(227, 227, 227));
        CoursesMainTitle.setText("Courses");
        CoursesMainTitle.setToolTipText("");

        javax.swing.GroupLayout CoursesTitlePanelLayout = new javax.swing.GroupLayout(CoursesTitlePanel);
        CoursesTitlePanel.setLayout(CoursesTitlePanelLayout);
        CoursesTitlePanelLayout.setHorizontalGroup(
            CoursesTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CoursesMainTitle)
                .addContainerGap(847, Short.MAX_VALUE))
        );
        CoursesTitlePanelLayout.setVerticalGroup(
            CoursesTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CoursesMainTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        CoursesMainPanel.add(CoursesTitlePanel, java.awt.BorderLayout.NORTH);

        Center.add(CoursesMainPanel);

        DashboardMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        DashboardMainPanel.setLayout(new javax.swing.OverlayLayout(DashboardMainPanel));

        DBMain.setLayout(new javax.swing.BoxLayout(DBMain, javax.swing.BoxLayout.Y_AXIS));
        DashboardMainPanel.add(DBMain);

        Center.add(DashboardMainPanel);

        SyllabusMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        SyllabusMainPanel.setLayout(new java.awt.BorderLayout());

        SyllabusTitlePanel.setBackground(new java.awt.Color(26, 24, 26));
        SyllabusTitlePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        SyllabusMainTitle.setBackground(new java.awt.Color(199, 50, 38));
        SyllabusMainTitle.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        SyllabusMainTitle.setForeground(new java.awt.Color(227, 227, 227));
        SyllabusMainTitle.setText("Syllabus");
        SyllabusMainTitle.setToolTipText("");

        javax.swing.GroupLayout SyllabusTitlePanelLayout = new javax.swing.GroupLayout(SyllabusTitlePanel);
        SyllabusTitlePanel.setLayout(SyllabusTitlePanelLayout);
        SyllabusTitlePanelLayout.setHorizontalGroup(
            SyllabusTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SyllabusMainTitle)
                .addContainerGap(843, Short.MAX_VALUE))
        );
        SyllabusTitlePanelLayout.setVerticalGroup(
            SyllabusTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SyllabusTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SyllabusMainTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SyllabusMainPanel.add(SyllabusTitlePanel, java.awt.BorderLayout.NORTH);

        SylMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        SylMainPanel.setPreferredSize(new java.awt.Dimension(100, 200));
        SylMainPanel.setLayout(new java.awt.CardLayout());

        SyllabusScrollPane.setPreferredSize(new java.awt.Dimension(793, 900));
        SylMainPanel.add(SyllabusScrollPane, "card4");

        SyllabusMainPanel.add(SylMainPanel, java.awt.BorderLayout.CENTER);

        Center.add(SyllabusMainPanel);

        StudentsMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        StudentsMainPanel.setLayout(new java.awt.BorderLayout());

        DBTitlePanel6.setBackground(new java.awt.Color(26, 24, 26));
        DBTitlePanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        StudentsMainTitle.setBackground(new java.awt.Color(199, 50, 38));
        StudentsMainTitle.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        StudentsMainTitle.setForeground(new java.awt.Color(227, 227, 227));
        StudentsMainTitle.setText("Students");
        StudentsMainTitle.setToolTipText("");

        javax.swing.GroupLayout DBTitlePanel6Layout = new javax.swing.GroupLayout(DBTitlePanel6);
        DBTitlePanel6.setLayout(DBTitlePanel6Layout);
        DBTitlePanel6Layout.setHorizontalGroup(
            DBTitlePanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(StudentsMainTitle)
                .addContainerGap(838, Short.MAX_VALUE))
        );
        DBTitlePanel6Layout.setVerticalGroup(
            DBTitlePanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(StudentsMainTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        StudentsMainPanel.add(DBTitlePanel6, java.awt.BorderLayout.NORTH);

        StudentsMP.setBackground(new java.awt.Color(26, 24, 26));
        StudentsMP.setPreferredSize(new java.awt.Dimension(100, 200));
        StudentsMP.setLayout(new java.awt.CardLayout());
        StudentsMP.add(StudentsScrollPane, "card4");

        StudentsMainPanel.add(StudentsMP, java.awt.BorderLayout.CENTER);

        Center.add(StudentsMainPanel);

        ReportsMainPanel.setBackground(new java.awt.Color(26, 24, 26));
        ReportsMainPanel.setLayout(new java.awt.BorderLayout());

        DBTitlePanel5.setBackground(new java.awt.Color(26, 24, 26));
        DBTitlePanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        DashboardMainTitle5.setBackground(new java.awt.Color(199, 50, 38));
        DashboardMainTitle5.setFont(new java.awt.Font("Prototype", 0, 24)); // NOI18N
        DashboardMainTitle5.setForeground(new java.awt.Color(227, 227, 227));
        DashboardMainTitle5.setText("Reports");
        DashboardMainTitle5.setToolTipText("");

        javax.swing.GroupLayout DBTitlePanel5Layout = new javax.swing.GroupLayout(DBTitlePanel5);
        DBTitlePanel5.setLayout(DBTitlePanel5Layout);
        DBTitlePanel5Layout.setHorizontalGroup(
            DBTitlePanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardMainTitle5)
                .addContainerGap(850, Short.MAX_VALUE))
        );
        DBTitlePanel5Layout.setVerticalGroup(
            DBTitlePanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DBTitlePanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DashboardMainTitle5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        ReportsMainPanel.add(DBTitlePanel5, java.awt.BorderLayout.NORTH);

        ReportsMP.setBackground(new java.awt.Color(26, 24, 26));
        ReportsMP.setPreferredSize(new java.awt.Dimension(100, 200));
        ReportsMP.setLayout(new java.awt.CardLayout());
        ReportsMP.add(ReportsScrollPane, "card4");

        ReportsMainPanel.add(ReportsMP, java.awt.BorderLayout.CENTER);

        Center.add(ReportsMainPanel);

        Main.add(Center, java.awt.BorderLayout.CENTER);

        getContentPane().add(Main, java.awt.BorderLayout.CENTER);

        getAccessibleContext().setAccessibleName("Tina");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddCourseCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCourseCancelButtonActionPerformed
        DisposeAddNewCourseDialog();
    }//GEN-LAST:event_AddCourseCancelButtonActionPerformed

    private void AddCourseIDFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AddCourseIDFieldKeyReleased

        if (courseManager.CheckIfExists(AddCourseIDField.getText()))
        {
            // The course already exists, set components accordingly.
            AddCourseWarning.setText("This course already exists!");
            AddCourseWarning.setVisible(true);
            AddCourseAddButton.setEnabled(false);
        }
        else
        {
            // The course does not exists, enable adding if the field is not empty.
            if (AddCourseIDField.getText().equals(""))
            {
                AddCourseWarning.setText("Course ID can not be empty!");
                AddCourseWarning.setVisible(true);
                AddCourseAddButton.setEnabled(false);
            }
            else
            {
                AddCourseWarning.setVisible(false);
                AddCourseAddButton.setEnabled(true);
            }
        }
    }//GEN-LAST:event_AddCourseIDFieldKeyReleased

    private void AddCourseAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCourseAddButtonActionPerformed
        // Add new course and select it.
        courseManager.AddNewCourse(AddCourseIDField.getText(), AddCourseNameField.getText(), AddCourseDescField.getText());
        SelectCourse(courseManager.GetCourseList().size() - 1);
        DisposeAddNewCourseDialog();
    }//GEN-LAST:event_AddCourseAddButtonActionPerformed

    private void EditCourseIDFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_EditCourseIDFieldKeyReleased

        // Check if newly typed id already equals to current edited course, if equals disable warning and enable save button.
        if (!courseManager.GetCourse(selectedCourse).getID().equals(EditCourseIDField.getText()))
        {
            // Check if the new name exists.
            if (courseManager.CheckIfExists(EditCourseIDField.getText()))
            {
                EditCourseWarning.setText("This course already exists!");
                EditCourseWarning.setVisible(true);
                EditCourseSaveButton.setEnabled(false);
            }
            else
            {
                // If not existing, check whether its empty or not. Don't allow empty name.
                if (EditCourseIDField.getText().equals(""))
                {
                    EditCourseWarning.setText("Course ID can not be empty!");
                    EditCourseWarning.setVisible(true);
                    EditCourseSaveButton.setEnabled(false);
                }
                else
                {
                    EditCourseWarning.setVisible(false);
                    EditCourseSaveButton.setEnabled(true);
                }
            }
        }
        else
        {
            EditCourseWarning.setVisible(false);
            EditCourseSaveButton.setEnabled(true);
        }


    }//GEN-LAST:event_EditCourseIDFieldKeyReleased

    private void EditCourseCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditCourseCancelButtonActionPerformed
        DisposeEditCourseDialog();
    }//GEN-LAST:event_EditCourseCancelButtonActionPerformed

    private void EditCourseSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditCourseSaveButtonActionPerformed
        // Edit course and select to update GUI.
        courseManager.GetCourse(selectedCourse).edit(EditCourseIDField.getText(), EditCourseNameField.getText(), EditCourseDescField.getText());
        SelectCourse(selectedCourse);
        DisposeEditCourseDialog();
    }//GEN-LAST:event_EditCourseSaveButtonActionPerformed

    private void AddSectionNameFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AddSectionNameFieldKeyReleased

        // Can not add an existing section.
        if (courseManager.GetCourse(selectedCourse).checkIfSectionExists(AddSectionNameField.getText()))
        {
            AddSectionWarning.setText("This section already exists!");
            AddSectionAddButton.setEnabled(false);
            AddSectionWarning.setVisible(true);
        }
        else
        {
            // Check if section name is empty, don't allow if so.
            if (AddSectionNameField.getText().equals(""))
            {
                AddSectionWarning.setText("Section name can not be empty!");
                AddSectionAddButton.setEnabled(false);
                AddSectionWarning.setVisible(true);
            }
            else
            {
                AddSectionAddButton.setEnabled(true);
                AddSectionWarning.setVisible(false);
            }

        }
    }//GEN-LAST:event_AddSectionNameFieldKeyReleased

    private void AddSectionCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSectionCancelButtonActionPerformed
        DisposeAddSectionDialog();
    }//GEN-LAST:event_AddSectionCancelButtonActionPerformed

    private void AddSectionAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSectionAddButtonActionPerformed
        // Add section and select it.
        courseManager.AddSectionToCourse(selectedCourse, AddSectionNameField.getText());
        SelectSection(courseManager.GetCourse(selectedCourse).getSections().size() - 1);
        DisposeAddSectionDialog();
    }//GEN-LAST:event_AddSectionAddButtonActionPerformed

    private void EditSectionNameFieldKeyReleased(java.awt.event.KeyEvent evt)//GEN-FIRST:event_EditSectionNameFieldKeyReleased
    {//GEN-HEADEREND:event_EditSectionNameFieldKeyReleased
        // TODO add your handling code here:

        // Check if the edited name exists.
        if (courseManager.GetCourse(selectedCourse).checkIfSectionExists(EditSectionNameField.getText()))
        {
            // If it exists and not the current section, out warning.
            if (!courseManager.GetCourse(selectedCourse).getSelectedSection().GetName().equals(EditSectionNameField.getText()))
            {
                EditSectionWarning.setText("This section already exists!");
                EditSectionSaveButton.setEnabled(false);
                EditSectionWarning.setVisible(true);
            }
        }
        else
        {
            // Dont allow empty fields.
            if (EditSectionNameField.getText().equals(""))
            {
                EditSectionWarning.setText("Section name can not be empty!");
                EditSectionSaveButton.setEnabled(false);
                EditSectionWarning.setVisible(true);
            }
            else
            {
                EditSectionSaveButton.setEnabled(true);
                EditSectionWarning.setVisible(false);
            }
        }
    }//GEN-LAST:event_EditSectionNameFieldKeyReleased

    private void EditSectionCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_EditSectionCancelActionPerformed
    {//GEN-HEADEREND:event_EditSectionCancelActionPerformed
        // TODO add your handling code here:
        DisposeEditSectionDialog();
    }//GEN-LAST:event_EditSectionCancelActionPerformed

    private void EditSectionSaveButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_EditSectionSaveButtonActionPerformed
    {//GEN-HEADEREND:event_EditSectionSaveButtonActionPerformed
        // Edit name and select it again to update GUI.
        courseManager.GetCourse(selectedCourse).getSelectedSection().SetName(EditSectionNameField.getText());
        SelectSection(courseManager.GetCourse(selectedCourse).getSelectedSectionIndex());
        DisposeEditSectionDialog();
    }//GEN-LAST:event_EditSectionSaveButtonActionPerformed

    private void AddLOCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_AddLOCancelActionPerformed
    {//GEN-HEADEREND:event_AddLOCancelActionPerformed
        AddLearningOutcomeDialog.dispose();
    }//GEN-LAST:event_AddLOCancelActionPerformed

    private void AddLOAddButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_AddLOAddButtonActionPerformed
    {//GEN-HEADEREND:event_AddLOAddButtonActionPerformed
        // Set GUI and select the newly added learning outcome list item.
        courseManager.GetCourse(selectedCourse).getSyllabus().addLearningOutcome(AddLOTextField.getText());
        AddLOTextField.setText("");
        AddLOWarning.setVisible(false);
        AddLOAddButton.setEnabled(false);
        SelectLearningOutcome(courseManager.GetCourse(selectedCourse).getSyllabus().getSelectedLO());
        AddLearningOutcomeDialog.dispose();

    }//GEN-LAST:event_AddLOAddButtonActionPerformed

    private void SaveLOCancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveLOCancelActionPerformed
    {//GEN-HEADEREND:event_SaveLOCancelActionPerformed
        EditLearningOutcomeDialog.dispose();
    }//GEN-LAST:event_SaveLOCancelActionPerformed

    private void SaveLOSaveButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveLOSaveButtonActionPerformed
    {//GEN-HEADEREND:event_SaveLOSaveButtonActionPerformed
        // Set GUI and update it.
        courseManager.GetCourse(selectedCourse).getSyllabus().editLearningOutcome(LearningOutcomeList.getSelectedIndex(), SaveLOTextField.getText());
        SaveLOTextField.setText("");
        SaveLOWarning.setVisible(false);
        SaveLOSaveButton.setEnabled(false);
        UpdateSyllabus();
        EditLearningOutcomeDialog.dispose();
    }//GEN-LAST:event_SaveLOSaveButtonActionPerformed

    private void AddLOTextFieldCaretUpdate(javax.swing.event.CaretEvent evt)//GEN-FIRST:event_AddLOTextFieldCaretUpdate
    {//GEN-HEADEREND:event_AddLOTextFieldCaretUpdate
        // Dont allow empty field.
        if (AddLOTextField.getText().equals(""))
        {
            AddLOWarning.setVisible(true);
            AddLOAddButton.setEnabled(false);
        }
        else
        {
            AddLOWarning.setVisible(false);
            AddLOAddButton.setEnabled(true);
        }
    }//GEN-LAST:event_AddLOTextFieldCaretUpdate

    private void SaveLOTextFieldCaretUpdate(javax.swing.event.CaretEvent evt)//GEN-FIRST:event_SaveLOTextFieldCaretUpdate
    {//GEN-HEADEREND:event_SaveLOTextFieldCaretUpdate
        // Dont allow empty field.
        if (SaveLOTextField.getText().equals(""))
        {
            SaveLOWarning.setVisible(true);
            SaveLOSaveButton.setEnabled(false);
        }
        else
        {
            SaveLOWarning.setVisible(false);
            SaveLOSaveButton.setEnabled(true);
        }
    }//GEN-LAST:event_SaveLOTextFieldCaretUpdate

    private void CourseSelectionComboBoxActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_CourseSelectionComboBoxActionPerformed
    {//GEN-HEADEREND:event_CourseSelectionComboBoxActionPerformed
        SelectCourse(CourseSelectionComboBox.getSelectedIndex());
    }//GEN-LAST:event_CourseSelectionComboBoxActionPerformed

    private void SectionSelectionComboBoxActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SectionSelectionComboBoxActionPerformed
    {//GEN-HEADEREND:event_SectionSelectionComboBoxActionPerformed
        SelectSection(SectionSelectionComboBox.getSelectedIndex());
    }//GEN-LAST:event_SectionSelectionComboBoxActionPerformed

    private void SelectLOListSelectButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectLOListSelectButtonActionPerformed
    {//GEN-HEADEREND:event_SelectLOListSelectButtonActionPerformed
        // Add the selected learning outcomes.
        courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().clearLOList();
        int[] indices = SelectLOList.getSelectedIndices();
        for (int i = 0; i < indices.length; i++)
            courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().addLO(indices[i]);

        // Update GUI & dispose.
        UpdateExams();
        SelectLODialog.dispose();
    }//GEN-LAST:event_SelectLOListSelectButtonActionPerformed

    private void SelectLOListMouseReleased(java.awt.event.MouseEvent evt)//GEN-FIRST:event_SelectLOListMouseReleased
    {//GEN-HEADEREND:event_SelectLOListMouseReleased
        SelectLOListSelectButton.setEnabled(SelectLOList.getSelectedIndex() != -1);
    }//GEN-LAST:event_SelectLOListMouseReleased

    private void SelectLOListCancelButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectLOListCancelButtonActionPerformed
    {//GEN-HEADEREND:event_SelectLOListCancelButtonActionPerformed
        SelectLODialog.dispose();
    }//GEN-LAST:event_SelectLOListCancelButtonActionPerformed

    private void SelectTopicListSelectButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectTopicListSelectButtonActionPerformed
    {//GEN-HEADEREND:event_SelectTopicListSelectButtonActionPerformed
        // Add selected learning outcomes.
        courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().clearTopicList();
        int[] indices = SelectTopicList.getSelectedIndices();

        for (int i = 0; i < indices.length; i++)
            courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().addTopic(indices[i]);

        // Update GUI & dispose.
        UpdateExams();
        SelectTopicDialog.dispose();
    }//GEN-LAST:event_SelectTopicListSelectButtonActionPerformed

    private void SelectTopicListMouseReleased(java.awt.event.MouseEvent evt)//GEN-FIRST:event_SelectTopicListMouseReleased
    {//GEN-HEADEREND:event_SelectTopicListMouseReleased
        SelectTopicListSelectButton.setEnabled(SelectTopicList.getSelectedIndex() != -1);
    }//GEN-LAST:event_SelectTopicListMouseReleased

    private void SelectTopicListCancelButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectTopicListCancelButtonActionPerformed
    {//GEN-HEADEREND:event_SelectTopicListCancelButtonActionPerformed
        SelectTopicDialog.dispose();
    }//GEN-LAST:event_SelectTopicListCancelButtonActionPerformed

    private void SelectLOListSelectEmptyButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectLOListSelectEmptyButtonActionPerformed
    {//GEN-HEADEREND:event_SelectLOListSelectEmptyButtonActionPerformed
        // Clear learning outcomes list & update.
        courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().clearLOList();
        UpdateExams();
        SelectLODialog.dispose();
    }//GEN-LAST:event_SelectLOListSelectEmptyButtonActionPerformed

    private void SelectTopicListSelectEmptyButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelectTopicListSelectEmptyButtonActionPerformed
    {//GEN-HEADEREND:event_SelectTopicListSelectEmptyButtonActionPerformed
        // Clear topics list and update.
        courseManager.GetCourse(selectedCourse).getSelectedExam().getSelectedQuestion().clearTopicList();
        UpdateExams();
        SelectTopicDialog.dispose();
    }//GEN-LAST:event_SelectTopicListSelectEmptyButtonActionPerformed

    private void FileChooserActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_FileChooserActionPerformed
    {//GEN-HEADEREND:event_FileChooserActionPerformed
        // Check the state. State is determined by the button that initiates the file chooser dialog.
        if (fileChooseState == FileChooseState.ExamResults)
        {
            // Try to load exam sheet.
            try
            {
                resourceManager.setCurrentExam(courseManager.GetCourse(selectedCourse).getSelectedExam());
                resourceManager.LoadExamXLSX(FileChooser.getSelectedFile());
            }
            catch (Exception e)
            {
               
            }
            
            // Update GUI.
            UpdateExams();
            UpdateReports();
        }
        else
        {
            try
            {
                // Try to load student sheet.
                resourceManager.setCurrentSection(courseManager.GetCourse(selectedCourse).getSelectedSection());
                resourceManager.LoadStudentXLSX(FileChooser.getSelectedFile());

                // Update GUI.
                UpdateStudents();
                UpdateReports();
            }
            catch (IOException ex)
            {
                Logger.getLogger(UIManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FileChooserActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {

        // Set anti aliasing on for fonts.
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Metal".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(UIManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(UIManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(UIManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(UIManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new UIManager().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCourseAddButton;
    private javax.swing.JButton AddCourseCancelButton;
    private javax.swing.JLabel AddCourseDesc;
    private javax.swing.JTextArea AddCourseDescField;
    private javax.swing.JScrollPane AddCourseDescPane;
    private javax.swing.JLabel AddCourseID;
    private javax.swing.JTextField AddCourseIDField;
    private javax.swing.JLabel AddCourseName;
    private javax.swing.JTextField AddCourseNameField;
    private javax.swing.JLabel AddCourseWarning;
    private javax.swing.JButton AddLOAddButton;
    private javax.swing.JButton AddLOCancel;
    private javax.swing.JLabel AddLOLabel;
    private javax.swing.JTextArea AddLOTextField;
    private javax.swing.JLabel AddLOWarning;
    private javax.swing.JDialog AddLearningOutcomeDialog;
    private javax.swing.JDialog AddNewCourseDialog;
    private javax.swing.JButton AddSectionAddButton;
    private javax.swing.JButton AddSectionCancelButton;
    private javax.swing.JDialog AddSectionDialog;
    private javax.swing.JLabel AddSectionName;
    private javax.swing.JTextField AddSectionNameField;
    private javax.swing.JLabel AddSectionWarning;
    private javax.swing.JPanel Center;
    private javax.swing.JComboBox<String> CourseSelectionComboBox;
    private javax.swing.JLabel CoursesImage;
    private javax.swing.JLabel CoursesLabel;
    private javax.swing.JPanel CoursesMainPanel;
    private javax.swing.JLabel CoursesMainTitle;
    private javax.swing.JPanel CoursesPanel;
    private javax.swing.JPanel CoursesTitlePanel;
    private javax.swing.JPanel CoursesWrapper;
    private javax.swing.JPanel DBMain;
    private javax.swing.JPanel DBTitlePanel4;
    private javax.swing.JPanel DBTitlePanel5;
    private javax.swing.JPanel DBTitlePanel6;
    private javax.swing.JLabel DashboardImage;
    private javax.swing.JLabel DashboardLabel;
    private javax.swing.JPanel DashboardMainPanel;
    private javax.swing.JLabel DashboardMainTitle4;
    private javax.swing.JLabel DashboardMainTitle5;
    private javax.swing.JPanel DashboardPanel;
    private javax.swing.JPanel DashboardWrapper;
    private javax.swing.JButton EditCourseCancelButton;
    private javax.swing.JLabel EditCourseDesc;
    private javax.swing.JTextArea EditCourseDescField;
    private javax.swing.JScrollPane EditCourseDescPane;
    private javax.swing.JDialog EditCourseDialog;
    private javax.swing.JLabel EditCourseID;
    private javax.swing.JTextField EditCourseIDField;
    private javax.swing.JLabel EditCourseName;
    private javax.swing.JTextField EditCourseNameField;
    private javax.swing.JButton EditCourseSaveButton;
    private javax.swing.JLabel EditCourseWarning;
    private javax.swing.JDialog EditLearningOutcomeDialog;
    private javax.swing.JButton EditSectionCancel;
    private javax.swing.JDialog EditSectionDialog;
    private javax.swing.JLabel EditSectionName;
    private javax.swing.JTextField EditSectionNameField;
    private javax.swing.JButton EditSectionSaveButton;
    private javax.swing.JLabel EditSectionWarning;
    private javax.swing.JLabel ExamsImage;
    private javax.swing.JLabel ExamsLabel;
    private javax.swing.JPanel ExamsMainPanel;
    private javax.swing.JPanel ExamsPanel;
    private javax.swing.JPanel ExamsWrapper;
    private javax.swing.JFileChooser FileChooser;
    private javax.swing.JPanel Left;
    private javax.swing.JPanel Main;
    private javax.swing.JPanel MenuPanel;
    private javax.swing.JLabel ReportsImage;
    private javax.swing.JLabel ReportsLabel;
    private javax.swing.JPanel ReportsMP;
    private javax.swing.JPanel ReportsMainPanel;
    private javax.swing.JPanel ReportsPanel;
    private javax.swing.JScrollPane ReportsScrollPane;
    private javax.swing.JPanel ReportsWrapper;
    private javax.swing.JButton SaveLOCancel;
    private javax.swing.JLabel SaveLOLabel;
    private javax.swing.JButton SaveLOSaveButton;
    private javax.swing.JTextArea SaveLOTextField;
    private javax.swing.JLabel SaveLOWarning;
    private javax.swing.JComboBox<String> SectionSelectionComboBox;
    private javax.swing.JDialog SelectLODialog;
    private javax.swing.JList<String> SelectLOList;
    private javax.swing.JButton SelectLOListCancelButton;
    private javax.swing.JButton SelectLOListSelectButton;
    private javax.swing.JButton SelectLOListSelectEmptyButton;
    private javax.swing.JDialog SelectTopicDialog;
    private javax.swing.JList<String> SelectTopicList;
    private javax.swing.JButton SelectTopicListCancelButton;
    private javax.swing.JButton SelectTopicListSelectButton;
    private javax.swing.JButton SelectTopicListSelectEmptyButton;
    private javax.swing.JLabel SelectedCourseLabel;
    private javax.swing.JLabel SelectedSectionLabel;
    private javax.swing.JLabel SettingsImage;
    private javax.swing.JLabel StudentsImage;
    private javax.swing.JLabel StudentsLabel;
    private javax.swing.JPanel StudentsMP;
    private javax.swing.JPanel StudentsMainPanel;
    private javax.swing.JLabel StudentsMainTitle;
    private javax.swing.JPanel StudentsPanel;
    private javax.swing.JScrollPane StudentsScrollPane;
    private javax.swing.JPanel StudentsWrapper;
    private javax.swing.JPanel SylMainPanel;
    private javax.swing.JLabel SyllabusImage;
    private javax.swing.JLabel SyllabusLabel;
    private javax.swing.JPanel SyllabusMainPanel;
    private javax.swing.JLabel SyllabusMainTitle;
    private javax.swing.JPanel SyllabusPanel;
    private javax.swing.JScrollPane SyllabusScrollPane;
    private javax.swing.JPanel SyllabusTitlePanel;
    private javax.swing.JPanel SyllabusWrapper;
    private javax.swing.JLabel Title;
    private javax.swing.JPanel Top;
    private javax.swing.JPanel TopCenter;
    private javax.swing.JPanel TopLeft;
    private javax.swing.JPanel TopRight;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane9;
    // End of variables declaration//GEN-END:variables
}
